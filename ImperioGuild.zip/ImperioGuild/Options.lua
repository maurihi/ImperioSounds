local A=ImperioGuild
-- Forever uses the modern Settings panel. This file makes IMPERIO Guild visible
-- under Esc -> Options -> AddOns; it also offers a direct key capture button.
local panel=CreateFrame('Frame','ImperioGuildSettingsPanel')
panel.name='ImperioGuild'
panel:SetSize(620,530)
local function text(parent,value,x,y,font,r,g,b)
 local fs=parent:CreateFontString(nil,'OVERLAY',font or 'GameFontNormal')
 fs:SetPoint('TOPLEFT',parent,'TOPLEFT',x,y)
 fs:SetText(value)
 if r then fs:SetTextColor(r,g,b) end
 return fs
end
local function button(label,x,y,w,callback)
 local b=CreateFrame('Button',nil,panel,'UIPanelButtonTemplate')
 b:SetSize(w or 195,28)
 b:SetPoint('TOPLEFT',panel,'TOPLEFT',x,y)
 b:SetText(label)
 b:SetScript('OnClick',callback)
 return b
end
local title=text(panel,'I M P E R I O   G U I L D',16,-18,'GameFontNormalLarge',1,.72,.31)
text(panel,'Sonidos  |  Emotes de la hermandad',16,-47,'GameFontHighlightSmall')
local hint=text(panel,'El botón IG se muestra junto al minimapa. Shift + arrastrar para moverlo.',16,-77,'GameFontNormalSmall',.9,.75,.58)
local miniBtn,soundBtn,emoteBtn,keyBtn
local status=text(panel,'',16,-442,'GameFontHighlightSmall',.94,.75,.42)
local function setStatus(msg)
 status:SetText(msg or '')
 if msg and A.Print then A:Print(msg) end
end
local function currentKey()
 if not GetBindingKey then return 'No disponible' end
 local ok,key=pcall(GetBindingKey,'IMPERIOGUILD_TOGGLE')
 return (ok and key) or 'Sin asignar'
end
local function refresh()
 local settings=A.db and A.db.settings or {}
 if miniBtn then miniBtn:SetText('Icono flotante: '..(settings.showMini~=false and 'VISIBLE' or 'OCULTO')) end
 if soundBtn then soundBtn:SetText('Sonidos: '..(settings.soundEnabled~=false and 'ACTIVADOS' or 'SILENCIADOS')) end
 if emoteBtn then emoteBtn:SetText('Emotes en chat: '..(settings.emoteImages~=false and 'ICONOS' or 'TEXTO')) end
 if keyBtn then keyBtn:SetText('Asignar tecla ('..currentKey()..')') end
end
miniBtn=button('Icono flotante: VISIBLE',16,-110,244,function()
 if not A.db then return end
 A:SetMiniVisible(A.db.settings.showMini==false)
 refresh()
end)
button('Restaurar posición del icono',278,-110,253,function()
 A:ResetMini()
 refresh()
 setStatus('Icono IG colocado a la izquierda del minimapa.')
end)
soundBtn=button('Sonidos: ACTIVADOS',16,-151,244,function()
 if not A.db then return end
 A.db.settings.soundEnabled=not A.db.settings.soundEnabled
 refresh()
end)
emoteBtn=button('Emotes en chat: ICONOS',278,-151,253,function()
 if not A.db then return end
 A.db.settings.emoteImages=not A.db.settings.emoteImages
 refresh()
end)
button('Abrir interfaz IMPERIO',16,-192,244,function() A:Toggle() end)
text(panel,'ATAJO PARA ABRIR / CERRAR IMPERIO',16,-253,'GameFontNormal',1,.72,.31)
text(panel,'También disponible en Esc > Opciones > Asignaciones de teclas > AddOns.',16,-277,'GameFontHighlightSmall')
local capturing=CreateFrame('Frame',nil,UIParent)
capturing:SetAllPoints(UIParent)
capturing:SetFrameStrata('FULLSCREEN_DIALOG')
capturing:EnableKeyboard(true)
if capturing.SetPropagateKeyboardInput then capturing:SetPropagateKeyboardInput(false) end
local mask=capturing:CreateTexture(nil,'BACKGROUND')
mask:SetAllPoints(capturing)
mask:SetColorTexture(.015,.015,.015,.76)
local captureLabel=text(capturing,'PULSA LA TECLA O COMBINACIÓN QUE QUIERAS\nESC para cancelar',0,0,'GameFontNormalLarge',1,.82,.47)
captureLabel:ClearAllPoints()
captureLabel:SetPoint('CENTER',capturing,'CENTER',0,0)
captureLabel:SetJustifyH('CENTER')
capturing:Hide()
local function finishCapture(message)
 capturing:Hide()
 refresh()
 if message then setStatus(message) end
end
capturing:SetScript('OnKeyDown',function(self,key)
 if key=='ESCAPE' then finishCapture('Asignación cancelada.');return end
 if key=='LSHIFT' or key=='RSHIFT' or key=='LCTRL' or key=='RCTRL' or key=='LALT' or key=='RALT'
   or key=='SHIFT' or key=='CTRL' or key=='ALT' or key=='UNKNOWN' then return end
 local binding=''
 if IsControlKeyDown() then binding=binding..'CTRL-' end
 if IsAltKeyDown() then binding=binding..'ALT-' end
 if IsShiftKeyDown() then binding=binding..'SHIFT-' end
 binding=binding..key
 if InCombatLockdown and InCombatLockdown() then
  finishCapture('No se pueden cambiar atajos durante el combate.');return
 end
 local assigned=GetBindingAction and GetBindingAction(binding) or ''
 if assigned and assigned~='' and assigned~='IMPERIOGUILD_TOGGLE' then
  finishCapture(binding..' ya está en uso. Elige otra combinación para no quitar la anterior.');return
 end
 if type(SetBinding)~='function' then finishCapture('La API SetBinding no está disponible.');return end
 local ok,success=pcall(SetBinding,binding,'IMPERIOGUILD_TOGGLE')
 if not ok or not success then finishCapture('No se pudo asignar '..binding..'.');return end
 if type(SaveBindings)=='function' and type(GetCurrentBindingSet)=='function' then
  pcall(SaveBindings,GetCurrentBindingSet())
 end
 finishCapture('Atajo de ImperioGuild configurado: '..binding)
end)
keyBtn=button('Asignar tecla',16,-313,244,function()
 if InCombatLockdown and InCombatLockdown() then setStatus('Sal de combate para cambiar el atajo.');return end
 capturing:Show()
end)
button('Quitar tecla asignada',278,-313,253,function()
 if InCombatLockdown and InCombatLockdown() then setStatus('Sal de combate para cambiar el atajo.');return end
 if not GetBindingKey or not SetBinding then return end
 local key1,key2=GetBindingKey('IMPERIOGUILD_TOGGLE')
 if key1 then pcall(SetBinding,key1) end
 if key2 then pcall(SetBinding,key2) end
 if SaveBindings and GetCurrentBindingSet then pcall(SaveBindings,GetCurrentBindingSet()) end
 setStatus('Atajo del addon eliminado.')
 refresh()
end)
text(panel,'Si desaparece el botón: /ig icon   |   Restaurar posición: /ig reseticon',16,-388,'GameFontNormalSmall',.89,.75,.54)
text(panel,'Abrir ventana sin botón: /ig   |   Probar audio: /ig sound calla ovin',16,-411,'GameFontNormalSmall',.89,.75,.54)
panel:SetScript('OnShow',refresh)
local category
local registered=false
local function registerSettings()
 if registered then return end
 local ok,err=pcall(function()
  if Settings and type(Settings.RegisterCanvasLayoutCategory)=='function' and
     type(Settings.RegisterAddOnCategory)=='function' then
   category=Settings.RegisterCanvasLayoutCategory(panel,'ImperioGuild')
   Settings.RegisterAddOnCategory(category)
   registered=true
  elseif type(InterfaceOptions_AddCategory)=='function' then
   InterfaceOptions_AddCategory(panel)
   registered=true
  end
 end)
 if not ok then A:Print('Error al registrar Opciones de IMPERIO: '..tostring(err)) end
end
registerSettings()
-- Some client builds finish loading their Settings UI at PLAYER_LOGIN.
local registrar=CreateFrame('Frame')
registrar:RegisterEvent('PLAYER_LOGIN')
registrar:SetScript('OnEvent',function() registerSettings() end)
function A:OpenOptions()
 if category and Settings and type(Settings.OpenToCategory)=='function' then
  local id=category.GetID and category:GetID() or category.ID or 'ImperioGuild'
  local success=pcall(Settings.OpenToCategory,id)
  if success then return end
 end
 if type(InterfaceOptionsFrame_OpenToCategory)=='function' then
  InterfaceOptionsFrame_OpenToCategory(panel)
 else
  self:Print('Opciones no disponibles. Usa /ig, /ig icon o los Atajos de teclado de WoW.')
 end
end
