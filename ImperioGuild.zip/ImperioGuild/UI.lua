local A=ImperioGuild
local frame=CreateFrame('Frame','ImperioGuildWindow',UIParent)
frame:SetSize(820,555)
frame:SetPoint('CENTER')
frame:SetFrameStrata('DIALOG')
frame:EnableMouse(true)
frame:SetMovable(true)
frame:RegisterForDrag('LeftButton')
frame:SetScript('OnDragStart',function(self) self:StartMoving() end)
frame:SetScript('OnDragStop',function(self) self:StopMovingOrSizing() end)
frame:Hide()

local function tex(parent,color,point1,rel,point2,x,y,w,h)
 local t=parent:CreateTexture(nil,'BACKGROUND')
 t:SetTexture('Interface\\Buttons\\WHITE8X8')
 t:SetVertexColor(unpack(color))
 if point1 then t:SetPoint(point1,rel or parent,point2 or point1,x or 0,y or 0) end
 if w then t:SetSize(w,h) end
 return t
end
local function label(parent,txt,size,x,y,color)
 local f=parent:CreateFontString(nil,'OVERLAY',size or 'GameFontNormal')
 f:SetPoint('TOPLEFT',parent,'TOPLEFT',x,y)
 f:SetText(txt)
 if color then f:SetTextColor(unpack(color)) end
 return f
end
local function button(parent,text,w,h,x,y,click)
 local b=CreateFrame('Button',nil,parent,'UIPanelButtonTemplate')
 b:SetSize(w,h)
 b:SetPoint('TOPLEFT',parent,'TOPLEFT',x,y)
 b:SetText(text)
 b:SetScript('OnClick',click)
 return b
end
tex(frame,{0.83,0.51,0.17,1},'TOPLEFT',frame,'TOPLEFT',0,0,820,555)
tex(frame,{0.07,0.045,0.045,0.98},'TOPLEFT',frame,'TOPLEFT',3,-3,814,549)
tex(frame,{0.35,0.025,0.025,1},'TOPLEFT',frame,'TOPLEFT',3,-3,814,65)
tex(frame,{0.85,0.29,0.08,1},'TOPLEFT',frame,'TOPLEFT',3,-68,814,2)
label(frame,'I M P E R I O','GameFontNormalHuge',20,-14,{1,0.77,0.38})
label(frame,'GUILD  •  SONIDOS Y EMOTES','GameFontNormalSmall',22,-44,{0.94,0.64,0.46})
button(frame,'X',30,26,778,-15,function() frame:Hide() end)

local tab='sounds'
local soundArea=CreateFrame('Frame',nil,frame)
soundArea:SetPoint('TOPLEFT',frame,'TOPLEFT',12,-105)
soundArea:SetSize(796,438)
local emoteArea=CreateFrame('Frame',nil,frame)
emoteArea:SetPoint('TOPLEFT',frame,'TOPLEFT',12,-105)
emoteArea:SetSize(796,438)
local function choose(name)
 tab=name
 if tab=='sounds' then soundArea:Show();emoteArea:Hide()
 else soundArea:Hide();emoteArea:Show() end
end
button(frame,'SONIDOS',155,27,17,-74,function() choose('sounds') end)
button(frame,'EMOTES',155,27,180,-74,function() choose('emotes') end)
button(frame,'OPCIONES',135,27,665,-74,function() if A.OpenOptions then A:OpenOptions() end end)

-- SONIDOS: 22 audios, incluidos On your left y Calla Ovin.
label(soundArea,'SONIDOS DE IMPERIO','GameFontNormalLarge',16,-12,{1,0.74,0.4})
label(soundArea,'Audios incluidos en el addon: no necesitas ImperioSounds','GameFontNormalSmall',16,-39,{0.76,0.68,0.62})
local channels={'GUILD','SAY','PARTY','RAID'}
local channelButton
local function cycle()
 if not A.db then return end
 local current=A.db.settings.channel
 local nextIndex=1
 for i,ch in ipairs(channels) do if ch==current then nextIndex=(i%#channels)+1;break end end
 A.db.settings.channel=channels[nextIndex]
 channelButton:SetText('CANAL: '..A.db.settings.channel)
end
channelButton=button(soundArea,'CANAL: GUILD',155,27,16,-67,cycle)
local mute=button(soundArea,'SONIDO: ON',140,27,178,-67,function(self)
 if not A.db then return end
 A.db.settings.soundEnabled=not A.db.settings.soundEnabled
 self:SetText(A.db.settings.soundEnabled and 'SONIDO: ON' or 'SONIDO: OFF')
end)
for i,word in ipairs(A.soundNames) do
 local col=(i-1)%5
 local line=math.floor((i-1)/5)
 button(soundArea,word,141,35,15+col*154,-110-line*48,function() A:SendWord(word) end)
end
label(soundArea,'Incluye On Your Left y Calla Ovin. Prueba: /ig sound calla ovin','GameFontNormalSmall',16,-370,{0.94,0.67,0.52})
label(soundArea,'El botón envía el mensaje al canal seleccionado y reproduce el sonido al recibirlo.','GameFontNormalSmall',16,-398,{0.76,0.68,0.62})

-- EMOTES: imágenes TGA locales por código + etiquetas de texto.
label(emoteArea,'EMOTES DE IMPERIO','GameFontNormalLarge',16,-12,{1,0.74,0.4})
label(emoteArea,'15 emotes originales IMPERIO incluidos. Clic para escribir el código en el chat.','GameFontNormalSmall',16,-42,{0.76,0.68,0.62})
for i,name in ipairs(A.emoteNames) do
 local col=(i-1)%5
 local line=math.floor((i-1)/5)
 local b=CreateFrame('Button',nil,emoteArea)
 b:SetSize(145,93)
 b:SetPoint('TOPLEFT',emoteArea,'TOPLEFT',11+col*156,-76-line*103)
 local base=b:CreateTexture(nil,'BACKGROUND')
 base:SetTexture('Interface\\Buttons\\WHITE8X8')
 base:SetVertexColor(0.18,0.055,0.055,0.9)
 base:SetAllPoints()
 local icon=b:CreateTexture(nil,'ARTWORK')
 icon:SetSize(52,52)
 icon:SetPoint('TOP',b,'TOP',0,-6)
 icon:SetTexture(A:EmoteTexture(name))
 local title=b:CreateFontString(nil,'OVERLAY','GameFontNormalSmall')
 title:SetPoint('TOP',b,'TOP',0,-61)
 title:SetText(':'..((A.emoteLabels and A.emoteLabels[name]) or name))
 local sub=b:CreateFontString(nil,'OVERLAY','GameFontDisableSmall')
 sub:SetPoint('TOP',b,'TOP',0,-79)
 sub:SetText('Escribir en chat')
 b:SetScript('OnClick',function() A:InsertEmote(name) end)
 b:SetScript('OnEnter',function(self)
  GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
  GameTooltip:SetText('Enviar :'..name)
  GameTooltip:AddLine('Emote original incluido. Clic para escribirlo en el chat.',1,0.72,0.45)
  GameTooltip:Show()
 end)
 b:SetScript('OnLeave',function() GameTooltip:Hide() end)
end
local imageMode=button(emoteArea,'ICONOS CHAT: ON',175,27,16,-399,function(self)
 if not A.db then return end
 A.db.settings.emoteImages=not A.db.settings.emoteImages
 self:SetText(A.db.settings.emoteImages and 'ICONOS CHAT: ON' or 'ICONOS CHAT: OFF')
end)
label(emoteArea,'Los demás necesitan IMPERIO Guild para ver las imágenes.','GameFontNormalSmall',203,-406,{0.94,0.67,0.52})

function A:Refresh() end
function A:Toggle()
 if frame:IsShown() then
  frame:Hide()
 else
  frame:Show();choose(tab)
  if self.db then
   channelButton:SetText('CANAL: '..self.db.settings.channel)
   mute:SetText(self.db.settings.soundEnabled and 'SONIDO: ON' or 'SONIDO: OFF')
   imageMode:SetText(self.db.settings.emoteImages and 'ICONOS CHAT: ON' or 'ICONOS CHAT: OFF')
  end
 end
end

-- Botón IG: visible, movible, con posición persistente y recuperación.
local mini=CreateFrame('Button','ImperioGuildMini',UIParent)
mini:SetSize(42,42)
mini:SetFrameStrata('HIGH')
mini:SetFrameLevel(500)
mini:SetClampedToScreen(true)
mini:SetMovable(true)
mini:EnableMouse(true)
mini:RegisterForDrag('LeftButton')
mini:RegisterForClicks('LeftButtonUp','RightButtonUp')
local edge=mini:CreateTexture(nil,'BACKGROUND')
edge:SetAllPoints(mini)
edge:SetTexture('Interface\\Buttons\\WHITE8X8')
edge:SetVertexColor(0.91,0.59,0.19,1)
local bg=mini:CreateTexture(nil,'BORDER')
bg:SetPoint('TOPLEFT',3,-3)
bg:SetPoint('BOTTOMRIGHT',-3,3)
bg:SetTexture('Interface\\Buttons\\WHITE8X8')
bg:SetVertexColor(0.33,0.025,0.025,1)
local letters=mini:CreateFontString(nil,'OVERLAY','GameFontNormalLarge')
letters:SetPoint('CENTER',mini,'CENTER',0,0)
letters:SetText('|cffffd183IG|r')
mini:SetScript('OnDragStart',function(self)
 if IsShiftKeyDown() then self:StartMoving() end
end)
mini:SetScript('OnDragStop',function(self)
 self:StopMovingOrSizing()
 if not A.db then return end
 local mx,my=self:GetCenter()
 local ux,uy=UIParent:GetCenter()
 if mx and ux then A.db.settings.miniPosition={x=mx-ux,y=my-uy} end
end)
mini:SetScript('OnClick',function(_,which)
 if which=='RightButton' and A.OpenOptions then A:OpenOptions() else A:Toggle() end
end)
mini:SetScript('OnEnter',function(self)
 GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
 GameTooltip:SetText('IMPERIO Guild',1,.82,.44)
 GameTooltip:AddLine('Clic: abrir sonidos y emotes',1,1,1)
 GameTooltip:AddLine('Shift + arrastrar: mover botón',.9,.74,.55)
 GameTooltip:AddLine('Clic derecho: opciones',.9,.74,.55)
 GameTooltip:Show()
end)
mini:SetScript('OnLeave',function() GameTooltip:Hide() end)
function A:ResetMini()
 if self.db then self.db.settings.miniPosition=nil end
 mini:ClearAllPoints()
 if Minimap then mini:SetPoint('TOPRIGHT',Minimap,'TOPLEFT',-8,-8)
 else mini:SetPoint('TOPRIGHT',UIParent,'TOPRIGHT',-260,-175) end
 mini:Show()
 if self.db then self.db.settings.showMini=true end
end
function A:UpdateMini()
 if not self.db then mini:Show();return end
 local settings=self.db.settings
 mini:ClearAllPoints()
 local pos=settings.miniPosition
 if type(pos)=='table' and tonumber(pos.x) and tonumber(pos.y) then
  mini:SetPoint('CENTER',UIParent,'CENTER',pos.x,pos.y)
 elseif Minimap then
  mini:SetPoint('TOPRIGHT',Minimap,'TOPLEFT',-8,-8)
 else
  mini:SetPoint('TOPRIGHT',UIParent,'TOPRIGHT',-260,-175)
 end
 if settings.showMini~=false then mini:Show() else mini:Hide() end
end
function A:SetMiniVisible(enabled)
 if self.db then self.db.settings.showMini=enabled and true or false end
 if enabled then self:UpdateMini();mini:Show() else mini:Hide() end
 self:Print(enabled and 'Icono IG visible. Shift + arrastrar para moverlo.' or 'Icono IG oculto. Recupera con /ig icon.')
end
mini:Show()
A:UpdateMini()
choose('sounds')
