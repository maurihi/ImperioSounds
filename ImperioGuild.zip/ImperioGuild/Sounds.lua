local A=ImperioGuild
local root='Interface\\AddOns\\ImperioGuild\\'
A.soundNames={'test','door','huh','wachu','yuhu','tres','necesito','teclado','español',
 'pito','ban','brr','elweso','fah','polvora','calabasa','cebolla','chivato','perdon','sad','on your left','calla ovin'}
A.soundFiles={test='prueba.ogg',['español']='espanol.ogg',['on your left']='onyourleft.mp3',onyourleft='onyourleft.mp3',['calla ovin']='ovin.ogg'}
for _,name in ipairs(A.soundNames) do if not A.soundFiles[name] then A.soundFiles[name]=name..'.ogg' end end
A.emoteNames={'cr','gm','o','s','t','dictador','puma','ultimate','gay','correa','piti','okey',
 'hello','monsterverde','monsterblanco'}
A.emotes={}
A.emoteLabels=A.emoteLabels or {}
for _,name in ipairs(A.emoteNames) do A.emotes[name]=root..'Emotes\\'..name..'.tga' end
function A:EmoteTexture(name)
 return self.emotes[name] or 'Interface\\Icons\\INV_Misc_QuestionMark'
end
function A:Play(word)
 if not self.db or not self.db.settings.soundEnabled then return false end
 if type(word)~='string' or (issecretvalue and issecretvalue(word)) then return false end
 local key=string.lower((word or ''):match('^%s*(.-)%s*$'))
 local file=self.soundFiles[key]
 if not file or type(PlaySoundFile)~='function' then return false end
 local ok,accepted=pcall(PlaySoundFile,root..'Sounds\\'..file,'Master')
 if not ok or not accepted then
  if key=='on your left' then
   local ok2,r2=pcall(PlaySoundFile,root..'Sounds\\onyourleft.ogg','Master')
   return ok2 and r2==true
  end
  return false
 end
 return true
end
function A:SendWord(word)
 if not word then return end
 local ch=self.db and self.db.settings.channel or 'GUILD'
 if ch=='GUILD' and not IsInGuild() then self:Print('No estás en una hermandad.'); return end
 local ok,err=pcall(SendChatMessage,word,ch)
 if not ok then self:Print('No se pudo enviar a '..ch..': '..tostring(err)) end
end
local function ReplaceEmotes(msg)
 if not ImperioGuildDB or not ImperioGuildDB.settings or not ImperioGuildDB.settings.emoteImages then return msg end
 if type(msg)~='string' or (issecretvalue and issecretvalue(msg)) then return msg end
 return (msg:gsub(':([%w_]+):?',function(name)
  local texture=A.emotes[string.lower(name)]
  if not texture then return nil end
  return '|T'..texture..':18:18:0:0|t'
 end))
end
local function ChatFilter(_,_,msg,...)
 if type(msg)~='string' or (issecretvalue and issecretvalue(msg)) then return false end
 local ok,translated=pcall(ReplaceEmotes,msg)
 if ok and translated~=msg then return false,translated,... end
 return false
end
if ChatFrame_AddMessageEventFilter then
 for _,event in ipairs({'CHAT_MSG_GUILD','CHAT_MSG_OFFICER','CHAT_MSG_SAY','CHAT_MSG_YELL','CHAT_MSG_EMOTE',
  'CHAT_MSG_PARTY','CHAT_MSG_PARTY_LEADER','CHAT_MSG_RAID','CHAT_MSG_RAID_LEADER',
  'CHAT_MSG_WHISPER','CHAT_MSG_WHISPER_INFORM','CHAT_MSG_CHANNEL','CHAT_MSG_INSTANCE_CHAT'}) do
  ChatFrame_AddMessageEventFilter(event,ChatFilter)
 end
end
local listener=CreateFrame('Frame')
for _,event in ipairs({'CHAT_MSG_GUILD','CHAT_MSG_SAY','CHAT_MSG_PARTY','CHAT_MSG_PARTY_LEADER',
 'CHAT_MSG_RAID','CHAT_MSG_RAID_LEADER'}) do listener:RegisterEvent(event) end
listener:SetScript('OnEvent',function(_,_,msg)
 if A.db then A:Play(msg) end
end)
