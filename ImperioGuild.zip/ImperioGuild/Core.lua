local A = CreateFrame('Frame')
ImperioGuild = A
A.version = '0.3.0-beta'
A.colors = {gold='ffffc66d',red='ffff554d',grey='ffaaaaaa',green='ff70e5a0'}

function A:Print(s)
 if DEFAULT_CHAT_FRAME then
  DEFAULT_CHAT_FRAME:AddMessage('|cffffc66d[ImperioGuild]|r '..tostring(s))
 end
end

A:RegisterEvent('ADDON_LOADED')
A:SetScript('OnEvent',function(self,event,addonName)
 if event~='ADDON_LOADED' or addonName~='ImperioGuild' then return end
 if type(ImperioGuildDB)~='table' then ImperioGuildDB={} end
 local db=ImperioGuildDB
 db.settings=db.settings or {}
 if db.settings.showMini==nil then db.settings.showMini=true end
 if db.settings.soundEnabled==nil then db.settings.soundEnabled=true end
 if db.settings.emoteImages==nil then db.settings.emoteImages=true end
 db.settings.channel=db.settings.channel or 'GUILD'
 self.db=db
 if self.UpdateMini then self:UpdateMini() end
 self:Print('Versión '..self.version..' cargada. /ig para abrir sonidos y emotes.')
end)

SLASH_IMPERIOGUILD1='/ig'
SLASH_IMPERIOGUILD2='/imperioguild'
SlashCmdList.IMPERIOGUILD=function(msg)
 local A=ImperioGuild
 msg=string.lower((msg or ''):match('^%s*(.-)%s*$'))
 if msg:sub(1,6)=='sound ' then
  local word=msg:sub(7)
  A:Print('Audio '..word..': '..(A:Play(word) and 'aceptado' or 'no aceptado'))
 elseif msg=='options' or msg=='config' then
  if A.OpenOptions then A:OpenOptions() end
 elseif msg=='icon' then
  if A.SetMiniVisible then A:SetMiniVisible(true) end
 elseif msg=='hideicon' then
  if A.SetMiniVisible then A:SetMiniVisible(false) end
 elseif msg=='reseticon' then
  if A.ResetMini then A:ResetMini() end
 elseif msg=='key' then
  A:Print('Usa /ig options para asignar una tecla.')
 elseif msg=='help' then
  A:Print('/ig abre; /ig sound [frase] prueba audio; /ig options ajustes; /ig icon recupera el botón; /ig reseticon recoloca el botón.')
 elseif msg=='' then
  if A.Toggle then A:Toggle() end
 else
  A:Print('Comando desconocido. Usa /ig help.')
 end
end

BINDING_HEADER_IMPERIOGUILD='ImperioGuild'
BINDING_NAME_IMPERIOGUILD_TOGGLE='Abrir/cerrar ImperioGuild'
