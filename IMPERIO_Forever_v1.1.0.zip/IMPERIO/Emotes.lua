local addonName, ns = ...
-- Emotes oficiales de IMPERIO. No hay emotes de prueba.
ns.emoteNames = {
 "cr", "gm", "o", "s", "t", "dictador", "puma", "ultimate",
 "gay", "correa", "piti", "okey", "monsterverde", "monsterblanco"
}
ns.emotes = {}
for _, name in ipairs(ns.emoteNames) do
 ns.emotes[name] = ns.emotePath .. name .. ".tga"
end

local function ReplaceEmotes(msg)
 if not ImperioDB or not ImperioDB.emotesEnabled or not ns.IsReadable(msg) then return msg end
 -- Both :nombre and :nombre: are accepted, protecting longer names with a word boundary.
 return (msg:gsub(":([%w_]+):?", function(name)
  local texture = ns.emotes[string.lower(name)]
  if not texture then return nil end
  return "|T" .. texture .. ":18:18:0:0|t"
 end))
end
local function EmoteFilter(chatFrame,event,msg,...)
 if not ns.IsReadable(msg) then return false end
 local translated = ReplaceEmotes(msg)
 if translated ~= msg then return false, translated, ... end
 return false
end
local filteredEvents = {
 "CHAT_MSG_SAY","CHAT_MSG_YELL","CHAT_MSG_EMOTE","CHAT_MSG_TEXT_EMOTE",
 "CHAT_MSG_PARTY","CHAT_MSG_PARTY_LEADER","CHAT_MSG_RAID","CHAT_MSG_RAID_LEADER",
 "CHAT_MSG_GUILD","CHAT_MSG_OFFICER","CHAT_MSG_WHISPER","CHAT_MSG_WHISPER_INFORM",
 "CHAT_MSG_INSTANCE_CHAT","CHAT_MSG_INSTANCE_CHAT_LEADER","CHAT_MSG_CHANNEL"
}
if ChatFrame_AddMessageEventFilter then
 for _, event in ipairs(filteredEvents) do
  ChatFrame_AddMessageEventFilter(event, EmoteFilter)
 end
end
ns.RenderEmotes = ReplaceEmotes
