local addonName, ns = ...
-- Chat autocomplete: : => show available emotes with small icons; click to insert.
-- Only reads local editable chat text. Protected/secret strings are ignored.
local MAX_ROWS = 8
local popup = CreateFrame("Frame", "ImperioEmoteAutocomplete", UIParent, "BackdropTemplate")
popup:SetSize(198, MAX_ROWS*27+12)
popup:SetFrameStrata("FULLSCREEN_DIALOG")
popup:SetClampedToScreen(true)
popup:EnableMouse(true)
if popup.SetBackdrop then
 popup:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", tile=true, tileSize=16,
  edgeSize=12,insets={left=4,right=4,top=4,bottom=4}})
 popup:SetBackdropColor(.02,.025,.035,.98)
end
popup:Hide()

local rows, matches = {}, {}
local activeEditBox, matchStart, matchEnd, skipOnce
local scrollOffset=0
local function IsEditable(editBox)
 return editBox and editBox.IsShown and editBox:IsShown() and editBox.HasFocus and editBox:HasFocus()
end
local function HidePopup() popup:Hide();activeEditBox=nil end

local function DrawRows()
 local total=#matches
 if scrollOffset>math.max(0,total-MAX_ROWS) then scrollOffset=math.max(0,total-MAX_ROWS) end
 local n=math.min(total,MAX_ROWS)
 popup:SetHeight(n*27+12)
 for i=1,MAX_ROWS do
  local row=rows[i]
  local name=matches[i+scrollOffset]
  if name then
   row.name=name
   row.icon:SetTexture(ns.emotes[name])
   row.text:SetText(":"..name)
   row:Show()
  else row:Hide() end
 end
end

local function InsertInto(editBox, name, replaceStart, replaceEnd)
 if not ns.IsReadable(name) or not ns.emotes[name] then return end
 if not IsEditable(editBox) or not editBox.GetText then
  if ChatFrame_OpenChat then ChatFrame_OpenChat(":"..name.." ",DEFAULT_CHAT_FRAME) end
  HidePopup()
  return
 end
 local ok, oldText=pcall(editBox.GetText,editBox)
 if not ok or not ns.IsReadable(oldText) then HidePopup();return end
 local startAt=replaceStart or (#oldText+1)
 local endAt=replaceEnd or #oldText
 if startAt<1 or endAt>#oldText then HidePopup();return end
 local inserted=":"..name.." "
 local result=oldText:sub(1,startAt-1)..inserted..oldText:sub(endAt+1)
 skipOnce=true
 editBox:SetText(result)
 if editBox.SetCursorPosition then editBox:SetCursorPosition(startAt-1+#inserted) end
 editBox:SetFocus()
 HidePopup()
end

for i=1,MAX_ROWS do
 local row=CreateFrame("Button",nil,popup,"BackdropTemplate")
 row:SetSize(182,26)
 row:SetPoint("TOPLEFT",popup,"TOPLEFT",8,-6-(i-1)*27)
 if row.SetBackdrop then
  row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
  row:SetBackdropColor(.09,.12,.15,.95)
 end
 row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
 local tex=row:CreateTexture(nil,"ARTWORK")
 tex:SetSize(21,21);tex:SetPoint("LEFT",row,"LEFT",4,0)
 row.icon=tex
 local label=row:CreateFontString(nil,"OVERLAY","GameFontHighlight")
 label:SetPoint("LEFT",tex,"RIGHT",8,0);label:SetJustifyH("LEFT")
 row.text=label
 row:SetScript("OnClick",function(self)
  if self.name and activeEditBox then
   InsertInto(activeEditBox,self.name,matchStart,matchEnd)
  end
 end)
 rows[i]=row
end
popup:EnableMouseWheel(true)
popup:SetScript("OnMouseWheel",function(self,delta)
 scrollOffset=math.max(0, math.min(math.max(0,#matches-MAX_ROWS),scrollOffset-delta))
 DrawRows()
end)

local function Update(editBox)
 if skipOnce then skipOnce=false;return end
 if not IsEditable(editBox) then HidePopup();return end
 local ok,textValue=pcall(editBox.GetText,editBox)
 if not ok or not ns.IsReadable(textValue) then HidePopup();return end
 local good,cursor=pcall(editBox.GetCursorPosition,editBox)
 if not good or type(cursor)~="number" then HidePopup();return end
 cursor=math.max(0,math.min(cursor,#textValue))
 local before=textValue:sub(1,cursor)
 -- Match a colon followed by an incomplete emote name directly before the cursor.
 local from,partial=before:match("():([%w_]*)$")
 if not from then HidePopup();return end
 -- Prevent reopening suggestions just after a fully completed :name: token.
 if from>1 and before:sub(from-1,from-1):match("[%w_:]") then
  HidePopup();return
 end
 partial=string.lower(partial)
 matches={}
 for _,name in ipairs(ns.emoteNames) do
  if name:sub(1,#partial)==partial then matches[#matches+1]=name end
 end
 if #matches==0 then HidePopup();return end
 activeEditBox=editBox
 matchStart=from
 matchEnd=cursor
 scrollOffset=0
 popup:ClearAllPoints()
 popup:SetPoint("BOTTOMLEFT",editBox,"TOPLEFT",0,4)
 DrawRows()
 popup:Show()
end

local installed=setmetatable({}, {__mode="k"})
local function Attach(editBox)
 if not editBox or installed[editBox] or not editBox.HookScript then return end
 installed[editBox]=true
 editBox:HookScript("OnTextChanged",function(self) Update(self) end)
 editBox:HookScript("OnCursorChanged",function(self) if self==activeEditBox then Update(self) end end)
 editBox:HookScript("OnEditFocusLost",function(self) if self==activeEditBox then HidePopup() end end)
 editBox:HookScript("OnHide",function(self) if self==activeEditBox then HidePopup() end end)
end

local watcher=CreateFrame("Frame")
watcher:RegisterEvent("PLAYER_LOGIN")
watcher:RegisterEvent("UPDATE_CHAT_WINDOWS")
watcher:SetScript("OnEvent",function()
 local total=(NUM_CHAT_WINDOWS or 10)
 for i=1,total do
  Attach(_G["ChatFrame"..i.."EditBox"])
 end
 Attach(_G.ChatFrameEditBox)
end)

function ns.InsertEmote(name)
 local eb=activeEditBox or (ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow())
 if eb and IsEditable(eb) then
  InsertInto(eb,name)
 elseif ChatFrame_OpenChat then
  ChatFrame_OpenChat(":"..name.." ",DEFAULT_CHAT_FRAME)
 end
end
