local addonName, ns = ...
local panel=CreateFrame("Frame","ImperioGuildPanel",UIParent,"BackdropTemplate")
panel:SetSize(438,505)
panel:SetPoint("CENTER",UIParent,"CENTER",0,0)
panel:SetFrameStrata("DIALOG")
panel:SetClampedToScreen(true)
panel:SetMovable(true)
panel:EnableMouse(true)
panel:RegisterForDrag("LeftButton")
panel:SetScript("OnDragStart",function(self) if IsControlKeyDown() then self:StartMoving() end end)
panel:SetScript("OnDragStop",function(self)
  self:StopMovingOrSizing()
  if ImperioDB then
    local point,_,relativePoint,x,y=self:GetPoint(1)
    ImperioDB.position={point=point,relativePoint=relativePoint,x=x,y=y}
  end
end)
if panel.SetBackdrop then
 panel:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=18,insets={left=5,right=5,top=5,bottom=5}})
 panel:SetBackdropColor(0.03,0.04,0.07,0.96)
end
local title=panel:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
title:SetPoint("TOP",0,-16)
title:SetText("IMPERIO  |  Guild Tools")
local sub=panel:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
sub:SetPoint("TOP",0,-42)
sub:SetText("CTRL + arrastrar para mover")
local close=CreateFrame("Button",nil,panel,"UIPanelCloseButton")
close:SetPoint("TOPRIGHT",-5,-5)
close:SetScript("OnClick",function() panel:Hide() end)

local toggle=CreateFrame("Button","ImperioGuildToggle",UIParent,"UIPanelButtonTemplate")
toggle:SetSize(85,30);toggle:SetPoint("CENTER",UIParent,"CENTER",-300,0)
toggle:SetFrameStrata("DIALOG");toggle:SetText("IMPERIO")
toggle:SetMovable(true);toggle:EnableMouse(true);toggle:RegisterForDrag("LeftButton")
toggle:SetScript("OnDragStart",function(self) if IsControlKeyDown() then self:StartMoving() end end)
toggle:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
toggle:SetScript("OnClick",function() if panel:IsShown() then panel:Hide() else panel:Show() end end)
ns.TogglePanel=function() if panel:IsShown() then panel:Hide() else panel:Show() end end

local function Button(parent,width,height,x,y)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
 b:SetSize(width,height);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
 return b
end
local soundTab=Button(panel,100,26,15,-62)
soundTab:SetText("Sonidos")
local emoteTab=Button(panel,100,26,121,-62)
emoteTab:SetText("Emotes")
local sounds=CreateFrame("Frame",nil,panel)
sounds:SetPoint("TOPLEFT",12,-98);sounds:SetSize(414,390)
local emotes=CreateFrame("Frame",nil,panel)
emotes:SetPoint("TOPLEFT",12,-98);emotes:SetSize(414,390)
local function ShowTab(which)
 if which=="sounds" then sounds:Show();emotes:Hide() else sounds:Hide();emotes:Show() end
end
soundTab:SetScript("OnClick",function() ShowTab("sounds") end)
emoteTab:SetScript("OnClick",function() ShowTab("emotes") end)

local mute=Button(sounds,125,27,5,0)
local channel=Button(sounds,155,27,140,0)
local function UpdateMute() mute:SetText(ImperioDB and ImperioDB.soundEnabled and "MUTE: OFF" or "MUTE: ON") end
local function UpdateChannel() channel:SetText("CANAL: /"..string.lower(ImperioDB and ImperioDB.channel or "SAY")) end
mute:SetScript("OnClick",function()
 ImperioDB.soundEnabled=not ImperioDB.soundEnabled
 UpdateMute()
end)
local channels={"SAY","PARTY","RAID"}
channel:SetScript("OnClick",function()
 local current=ImperioDB.channel
 for i,ch in ipairs(channels) do
  if ch==current then ImperioDB.channel=channels[(i%#channels)+1];break end
 end
 UpdateChannel()
end)
for i,name in ipairs(ns.soundNames) do
 local col=(i-1)%4
 local row=math.floor((i-1)/4)
 local b=Button(sounds,96,31,4+col*102,-39-row*38)
 b:SetText(name)
 b:SetScript("OnClick",function() ns.SendText(name) end)
end
local note=sounds:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
note:SetPoint("BOTTOM",sounds,"BOTTOM",0,0)
note:SetText("Se reproduce al escribir la palabra exacta en el chat")

local emoteMute=Button(emotes,180,28,5,0)
local function UpdateEmoteMute()
 emoteMute:SetText(ImperioDB and ImperioDB.emotesEnabled and "Emotes: ACTIVADOS" or "Emotes: DESACTIVADOS")
end
emoteMute:SetScript("OnClick",function()
 ImperioDB.emotesEnabled=not ImperioDB.emotesEnabled
 UpdateEmoteMute()
end)
local hint=emotes:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
hint:SetPoint("TOPLEFT",emotes,"TOPLEFT",6,-38)
hint:SetText("Escribe :nombre en el chat; al poner : aparecera una lista.")
for i,name in ipairs(ns.emoteNames) do
 local col=(i-1)%4
 local row=math.floor((i-1)/4)
 local b=CreateFrame("Button",nil,emotes,"BackdropTemplate")
 b:SetSize(94,68)
 b:SetPoint("TOPLEFT",emotes,"TOPLEFT",3+col*103,-63-row*76)
 if b.SetBackdrop then
  b:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=10})
  b:SetBackdropColor(.08,.1,.13,.95)
 end
 local art=b:CreateTexture(nil,"ARTWORK")
 art:SetTexture(ns.emotes[name]);art:SetSize(39,39);art:SetPoint("TOP",0,-3)
 local label=b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
 label:SetPoint("BOTTOM",0,5);label:SetText(":"..name)
 b:SetScript("OnClick",function()
  if ns.InsertEmote then ns.InsertEmote(name) end
 end)
end
local footer=emotes:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
footer:SetPoint("BOTTOM",emotes,"BOTTOM",0,6)
footer:SetText("Solo los miembros con IMPERIO veran las imagenes")

panel:RegisterEvent("ADDON_LOADED")
panel:SetScript("OnEvent",function(self,event,name)
 if name~=addonName then return end
 UpdateMute();UpdateChannel();UpdateEmoteMute()
 if ImperioDB and ImperioDB.position then
  local p=ImperioDB.position
  if p.point and p.relativePoint and p.x and p.y then
   self:ClearAllPoints();self:SetPoint(p.point,UIParent,p.relativePoint,p.x,p.y)
  end
 end
 self:UnregisterEvent("ADDON_LOADED")
end)
ShowTab("sounds")
panel:Hide()
