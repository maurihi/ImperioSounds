
print("|cFFFF0000IMPERIOSOUNDS PANEL CARGADO|r")

local SOUND_NAMES = {
    "test",
    "door",
    "huh",
    "wachu",
    "yuhu",
    "tres",
    "necesito",
    "teclado",
    "español",
    "pito",
    "ban",
    "brr",
    "elweso",
    "fah",
    "polvora",
    "calabasa",
    "cebolla",
    "chivato",
    "perdon",
    "sad",
}

-- BOTON FLOTANTE
local toggle = CreateFrame(
    "Button",
    "ImperioSoundsToggle",
    UIParent,
    "UIPanelButtonTemplate"
)

toggle:SetSize(65, 35)
toggle:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
toggle:SetFrameStrata("DIALOG")
toggle:SetText("IS")

toggle:SetMovable(true)
toggle:RegisterForDrag("LeftButton")

toggle:SetScript("OnDragStart", function(self)
    if IsControlKeyDown() then
        self:StartMoving()
    end
end)

toggle:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
end)

toggle:Show()

-- PANEL DESPLEGABLE
local panel = CreateFrame("Frame", "ImperioSoundsPanel", UIParent)

panel:SetSize(310, 245)
panel:SetPoint("TOP", toggle, "BOTTOM", 0, -8)
panel:SetFrameStrata("DIALOG")
panel:SetFrameLevel(toggle:GetFrameLevel() + 2)

-- FONDO
local bg = panel:CreateTexture(nil, "BACKGROUND")
bg:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
bg:SetAllPoints(panel)
bg:SetVertexColor(0.8, 0.8, 0.8, 1)

-- TITULO
local title = panel:CreateFontString(
    nil,
    "OVERLAY",
    "GameFontNormalLarge"
)

title:SetPoint("TOP", panel, "TOP", 0, -12)
title:SetText("ImperioSounds")

-- BOTON CERRAR
local close = CreateFrame(
    "Button",
    nil,
    panel,
    "UIPanelCloseButton"
)

close:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -3, -3)

close:SetScript("OnClick", function()
    panel:Hide()
end)

-- BOTONES DE SONIDOS
for i, word in ipairs(SOUND_NAMES) do

    local button = CreateFrame(
        "Button",
        nil,
        panel,
        "UIPanelButtonTemplate"
    )

    button:SetSize(68, 30)

    local column = (i - 1) % 4
    local row = math.floor((i - 1) / 4)

    button:SetPoint(
        "TOPLEFT",
        panel,
        "TOPLEFT",
        10 + column * 74,
        -42 - row * 37
    )

    button:SetText(word)

    button:SetScript("OnClick", function()

        if IsInRaid() then
            print("ImperioSounds: No funciona en bandas.")
            return
        end

        -- Enviar palabra por /say
        SendChatMessage(word, "SAY")

    end)
end

-- OCULTAR PANEL AL INICIAR
panel:Hide()

-- MOSTRAR / OCULTAR CON EL BOTON IS
toggle:SetScript("OnClick", function()

    if panel:IsShown() then
        panel:Hide()
    else
        panel:Show()
    end

end)

print("|cFF00FF00ImperioSounds: Panel creado correctamente.|r")
