
local SOUND_NAMES = {
    "test",
    "door",
    "huh",
    "wachu",
    "yuhu",
    "tres",
    "necesito",
    "teclado",
    "español",
    "pito",
    "ban",
    "brr",
    "elweso",
    "fah",
    "polvora",
    "calabasa",
    "cebolla",
    "chivato",
    "perdon",
    "sad",
}

-- BOTON FLOTANTE
local toggle = CreateFrame(
    "Button",
    "ImperioSoundsToggle",
    UIParent,
    "UIPanelButtonTemplate"
)

toggle:SetSize(65, 35)
toggle:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
toggle:SetFrameStrata("DIALOG")
toggle:SetText("IS")

-- Mover con CTRL + clic izquierdo
toggle:SetMovable(true)
toggle:RegisterForDrag("LeftButton")

toggle:SetScript("OnDragStart", function(self)
    if IsControlKeyDown() then
        self:StartMoving()
    end
end)

toggle:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
end)

toggle:Show()

-- PANEL DESPLEGABLE
local panel = CreateFrame("Frame", "ImperioSoundsPanel", UIParent)

panel:SetSize(330, 280)
panel:SetPoint("TOP", toggle, "BOTTOM", 0, -8)
panel:SetFrameStrata("DIALOG")
panel:SetFrameLevel(toggle:GetFrameLevel() + 2)

-- FONDO
local bg = panel:CreateTexture(nil, "BACKGROUND")
bg:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
bg:SetAllPoints(panel)
bg:SetVertexColor(0.8, 0.8, 0.8, 1)

-- TITULO
local title = panel:CreateFontString(
    nil,
    "OVERLAY",
    "GameFontNormalLarge"
)

title:SetPoint("TOP", panel, "TOP", 0, -12)
title:SetText("ImperioSounds")

-- BOTON CERRAR
local close = CreateFrame(
    "Button",
    nil,
    panel,
    "UIPanelCloseButton"
)

close:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -3, -3)

close:SetScript("OnClick", function()
    panel:Hide()
end)

-- BOTON MUTE
local muteButton = CreateFrame(
    "Button",
    nil,
    panel,
    "UIPanelButtonTemplate"
)

muteButton:SetSize(110, 25)
muteButton:SetPoint("TOP", panel, "TOP", -65, -37)

local function UpdateMuteButton()
    if ImperioSoundsEnabled then
        muteButton:SetText("MUTE: OFF")
    else
        muteButton:SetText("MUTE: ON")
    end
end

UpdateMuteButton()

muteButton:SetScript("OnClick", function()
    ImperioSoundsEnabled = not ImperioSoundsEnabled
    UpdateMuteButton()

    if ImperioSoundsEnabled then
        print("|cFF00FF00ImperioSounds: Sonido activado.|r")
    else
        print("|cFFFF0000ImperioSounds: Sonido silenciado.|r")
    end
end)

-- BOTON CAMBIAR CANAL
local channelButton = CreateFrame(
    "Button",
    nil,
    panel,
    "UIPanelButtonTemplate"
)

channelButton:SetSize(125, 25)
channelButton:SetPoint("TOP", panel, "TOP", 65, -37)

local CHANNELS = {
    "SAY",
    "PARTY",
    "RAID",
}

local function UpdateChannelButton()
    channelButton:SetText("CANAL: /" .. string.lower(ImperioSoundsChannel))
end

UpdateChannelButton()

channelButton:SetScript("OnClick", function()

    local currentIndex = 1

    for i, channel in ipairs(CHANNELS) do
        if channel == ImperioSoundsChannel then
            currentIndex = i
            break
        end
    end

    currentIndex = currentIndex + 1

    if currentIndex > #CHANNELS then
        currentIndex = 1
    end

    ImperioSoundsChannel = CHANNELS[currentIndex]

    UpdateChannelButton()

    print("|cFF00FF00ImperioSounds: Canal cambiado a /" ..
        string.lower(ImperioSoundsChannel) .. "|r")
end)

-- BOTONES DE SONIDOS
for i, word in ipairs(SOUND_NAMES) do

    local button = CreateFrame(
        "Button",
        nil,
        panel,
        "UIPanelButtonTemplate"
    )

    button:SetSize(72, 30)

    local column = (i - 1) % 4
    local row = math.floor((i - 1) / 4)

    button:SetPoint(
        "TOPLEFT",
        panel,
        "TOPLEFT",
        10 + column * 78,
        -75 - row * 37
    )

    button:SetText(word)

    button:SetScript("OnClick", function()

        -- Enviar la palabra por el canal seleccionado
        SendChatMessage(word, ImperioSoundsChannel)

    end)
end

-- OCULTAR PANEL AL INICIAR
panel:Hide()

-- MOSTRAR / OCULTAR PANEL
toggle:SetScript("OnClick", function()

    if panel:IsShown() then
        panel:Hide()
    else
        panel:Show()
    end

end)

print("|cFF00FF00ImperioSounds: Panel creado correctamente.|r")
