
local frame = CreateFrame("Frame")

local SOUND_FOLDER = "Interface\\AddOns\\ImperioSounds\\Sounds\\"

-- Configuracion compartida con Panel.lua
if ImperioSoundsEnabled == nil then
    ImperioSoundsEnabled = true
end

if ImperioSoundsChannel == nil then
    ImperioSoundsChannel = "SAY"
end

local SOUNDS = {
    ["test"] = "prueba.ogg",
    ["door"] = "door.ogg",
    ["huh"] = "huh.ogg",
    ["wachu"] = "wachu.ogg",
    ["yuhu"] = "yuhu.ogg",
    ["tres"] = "tres.ogg",
    ["necesito"] = "necesito.ogg",
    ["teclado"] = "teclado.ogg",
    ["español"] = "español.ogg",
    ["pito"] = "pito.ogg",
    ["ban"] = "ban.ogg",
    ["brr"] = "brr.ogg",
    ["elweso"] = "elweso.ogg",
    ["fah"] = "fah.ogg",
    ["polvora"] = "polvora.ogg",
    ["calabasa"] = "calabasa.ogg",
    ["cebolla"] = "cebolla.ogg",
    ["chivato"] = "chivato.ogg",
    ["perdon"] = "perdon.ogg",
    ["sad"] = "sad.ogg",
}

-- Escuchar mensajes de todos los canales
frame:RegisterEvent("CHAT_MSG_SAY")
frame:RegisterEvent("CHAT_MSG_PARTY")
frame:RegisterEvent("CHAT_MSG_PARTY_LEADER")
frame:RegisterEvent("CHAT_MSG_RAID")
frame:RegisterEvent("CHAT_MSG_RAID_LEADER")

frame:SetScript("OnEvent", function(self, event, message, sender)

    local word = string.lower(message or "")
    local file = SOUNDS[word]

    if file and ImperioSoundsEnabled then
        local path = SOUND_FOLDER .. file

        PlaySoundFile(path, "Master")

        print("|cFF00FF00ImperioSounds:|r " ..
            word .. " detectado (" .. tostring(sender or "desconocido") .. ")")
    end
end)

print("|cFF00FF00ImperioSounds cargado correctamente.|r")

-- Comando para probar sonidos
SLASH_IMPERIOSOUNDS1 = "/istest"

SlashCmdList["IMPERIOSOUNDS"] = function(msg)

    if not ImperioSoundsEnabled then
        print("|cFFFF0000ImperioSounds: Sonido silenciado.|r")
        return
    end

    local file = string.lower(msg) .. ".ogg"
    local path = SOUND_FOLDER .. file

    local result = PlaySoundFile(path, "Master")

    print("ImperioSounds:", result, file)
end

