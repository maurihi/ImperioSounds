
local frame = CreateFrame("Frame")

local SOUND_FOLDER = "Interface\\AddOns\\ImperioSounds\\Sounds\\"

local SOUNDS = {
    ["test"] = "prueba.ogg",
    ["door"] = "door.ogg",
    ["huh"] = "huh.ogg",
    ["wachu"] = "wachu.ogg",
    ["yuhu"] = "yuhu.ogg",
    ["tres"] = "tres.ogg",
    ["necesito"] = "necesito.ogg",
    ["teclado"] = "teclado.ogg",
    ["español"] = "español.ogg",
    ["pito"] = "pito.ogg",
    ["ban"] = "ban.ogg",
    ["brr"] = "brr.ogg",
    ["elweso"] = "elweso.ogg",
    ["fah"] = "fah.ogg",
    ["polvora"] = "polvora.ogg",
    ["calabasa"] = "calabasa.ogg",
    ["cebolla"] = "cebolla.ogg",
    ["chivato"] = "chivato.ogg",
    ["perdon"] = "perdon.ogg",
    ["sad"] = "sad.ogg",
}

-- Eventos de chat
frame:RegisterEvent("CHAT_MSG_SAY")
frame:RegisterEvent("CHAT_MSG_PARTY")

frame:SetScript("OnEvent", function(self, event, message, sender)

    if IsInRaid() then
        return
    end

    local word = string.lower(message)
    local file = SOUNDS[word]

    if file then
        local path = SOUND_FOLDER .. file

        PlaySoundFile(path, "Master")

        print("|cFF00FF00ImperioSounds:|r " ..
            word .. " detectado (" .. sender .. ")")
    end
end)

print("|cFF00FF00ImperioSounds cargado correctamente.|r")

-- Comando para probar sonidos
SLASH_IMPERIOSOUNDS1 = "/istest"

SlashCmdList["IMPERIOSOUNDS"] = function(msg)
    local file = string.lower(msg) .. ".ogg"
    local path = SOUND_FOLDER .. file

    local result = PlaySoundFile(path, "Master")

    print("ImperioSounds:", result, file)
end
