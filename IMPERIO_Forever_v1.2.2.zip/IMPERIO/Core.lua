local addonName, ns = ...
ns = ns or {}
local ADDON_PATH = "Interface\\AddOns\\IMPERIO\\"
ns.path = ADDON_PATH
ns.soundPath = ADDON_PATH .. "Sounds\\"
ns.emotePath = ADDON_PATH .. "Emotes\\"

ns.soundNames = {
 "test", "door", "huh", "wachu", "yuhu", "tres", "necesito", "teclado",
 "español", "pito", "ban", "brr", "elweso", "fah", "polvora",
 "calabasa", "cebolla", "chivato", "perdon", "sad", "on your left"
}
ns.soundFiles = {
 ["test"]="prueba.ogg", ["door"]="door.ogg", ["huh"]="huh.ogg",
 ["wachu"]="wachu.ogg", ["yuhu"]="yuhu.ogg", ["tres"]="tres.ogg",
 ["necesito"]="necesito.ogg", ["teclado"]="teclado.ogg",
 ["español"]="espanol.ogg", ["pito"]="pito.ogg", ["ban"]="ban.ogg",
 ["brr"]="brr.ogg", ["elweso"]="elweso.ogg", ["fah"]="fah.ogg",
 ["polvora"]="polvora.ogg", ["calabasa"]="calabasa.ogg",
 ["cebolla"]="cebolla.ogg", ["chivato"]="chivato.ogg",
 ["perdon"]="perdon.ogg", ["sad"]="sad.ogg",
 ["on your left"]="onyourleft.ogg"
}

local frame=CreateFrame("Frame")
local supportedChannels={SAY=true,PARTY=true,RAID=true}
local function log(msg) print("|cffd9b45fIMPERIO:|r " .. msg) end
ns.log=log

local function IsReadable(value)
  if issecretvalue and issecretvalue(value) then return false end
  if type(value) ~= "string" then return false end
  return true
end
ns.IsReadable=IsReadable

function ns.PlaySound(word)
  if not ImperioDB or not ImperioDB.soundEnabled then return false end
  if not IsReadable(word) then return false end
  local filename=ns.soundFiles[string.lower(word)]
  if not filename then return false end
  local ok = PlaySoundFile(ns.soundPath .. filename, "Master")
  return ok and true or false
end

local function SafeChannel()
  local selected=(ImperioDB and ImperioDB.channel) or "SAY"
  if selected=="RAID" then
    if IsInRaid and IsInRaid() then return (UnitIsGroupLeader("player") and "RAID_LEADER") or "RAID" end
    if IsInGroup and IsInGroup() then return (UnitIsGroupLeader("player") and "PARTY_LEADER") or "PARTY" end
    return "SAY"
  elseif selected=="PARTY" then
    if IsInRaid and IsInRaid() then return (UnitIsGroupLeader("player") and "RAID_LEADER") or "RAID" end
    if IsInGroup and IsInGroup() then return (UnitIsGroupLeader("player") and "PARTY_LEADER") or "PARTY" end
    return "SAY"
  end
  return "SAY"
end
function ns.SendText(message)
  if not IsReadable(message) or message=="" then return end
  local ch=SafeChannel()
  -- Modern WoW accepts SAY/PARTY/RAID; LEADER channels may have specific availability.
  local ok=pcall(SendChatMessage,message,ch)
  if not ok and (ch=="RAID_LEADER" or ch=="PARTY_LEADER") then
    SendChatMessage(message,ch=="RAID_LEADER" and "RAID" or "PARTY")
  end
end

local events={"CHAT_MSG_SAY","CHAT_MSG_PARTY","CHAT_MSG_PARTY_LEADER",
 "CHAT_MSG_RAID","CHAT_MSG_RAID_LEADER"}
for _,ev in ipairs(events) do frame:RegisterEvent(ev) end
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent",function(self,event,...)
  if event=="ADDON_LOADED" then
    local name=...
    if name~=addonName then return end
    ImperioDB = ImperioDB or {}
    if ImperioDB.soundEnabled==nil then ImperioDB.soundEnabled=true end
    if ImperioDB.emotesEnabled==nil then ImperioDB.emotesEnabled=true end
    if not supportedChannels[ImperioDB.channel] then ImperioDB.channel="SAY" end
    self:UnregisterEvent("ADDON_LOADED")
    log("cargado. Abre el panel con /imperio")
    return
  end
  local message=...
  if not ImperioDB or not ImperioDB.soundEnabled or not IsReadable(message) then return end
  local word=string.lower(message)
  if ns.soundFiles[word] then ns.PlaySound(word) end
end)

SLASH_IMPERIO1="/imperio"
SLASH_IMPERIO2="/imp"
SlashCmdList.IMPERIO=function(message)
  if ns.TogglePanel then ns.TogglePanel() end
end
SLASH_IMPERIOTEST1="/istest"
SlashCmdList.IMPERIOTEST=function(message)
  if not IsReadable(message) then return end
  local key=string.lower(message or "")
  if not ns.soundFiles[key] then log("Usa /istest nombre. Ej: /istest brr")
  elseif not ImperioDB.soundEnabled then log("Sonidos silenciados")
  else local success=ns.PlaySound(key); log(key .. (success and " reproducido" or " - no se pudo reproducir")) end
end
